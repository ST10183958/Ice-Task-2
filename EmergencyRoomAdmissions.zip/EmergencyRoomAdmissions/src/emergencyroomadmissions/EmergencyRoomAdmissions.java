/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package emergencyroomadmissions;
import java.util.Scanner;
/**
 *
 * @author kuri
 */
public class EmergencyRoomAdmissions {


    public static void main(String[] args) {
        Scanner ScannerObj = new Scanner(System.in);
        
        String[] Names = {"Samantha", "Johny", "Sam", "Ricky", "Brock", "Julia", "Tricksi", "Stephanie"};
        int[] Ages = {16,19,18,20,16,15,20,21};
        String[] Genders = {"Female", "Male", "Male", "Male", "Male", "Female", "Female", "Female"};
                
        System.out.print("Enter User:");
        String UsernameInput = ScannerObj.nextLine();
        
        System.out.print("Enter Password:");
        String PasswordInput = ScannerObj.nextLine();
        
        if(UsernameInput.equals("Admin") && PasswordInput.equals("St@a77")) {
            System.out.print("Search for user:");
            String UserInput = ScannerObj.nextLine();
            String SearchUserMethod = SearchUserMethod(UserInput, Names, Ages,Genders );
            System.out.println(SearchUserMethod);
        } else {
            System.out.println("Username or Password is incorrect");
        }

    }
    
    public static String SearchUserMethod(String UsernameInput, String[]  Names, int[] Ages, String[] Genders) {
        
        String UserExists = "Empty";
       
        for (String item : Names) {
            if (item.equals(UsernameInput)) {
                UserExists = "found";
            }
        }
        
        return UserExists;
    }    
    
}
